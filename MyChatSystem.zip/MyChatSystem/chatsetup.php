<?php
$fp = fopen('message.txt', 'w');
fwrite($fp, 'Your Name');
fclose($fp);
?>
